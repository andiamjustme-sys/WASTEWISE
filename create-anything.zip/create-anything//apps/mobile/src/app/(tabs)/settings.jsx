import React, { useState } from 'react';
import { View, Text, ScrollView, TouchableOpacity, Switch } from 'react-native';
import { StatusBar } from 'expo-status-bar';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { 
  User, 
  Palette, 
  Trophy, 
  Award, 
  Zap, 
  Moon, 
  Sun, 
  Sparkles,
  LogOut,
  ChevronRight,
  Target,
  Flame
} from 'lucide-react-native';

// Mock user data (in real app, this would come from auth/database)
const userData = {
  name: 'Emily',
  email: 'emily@example.com',
  level: 'Eco Explorer',
  totalPoints: 88,
  currentStreak: 5,
  totalImpact: '2.3kg waste saved'
};

const badges = [
  { id: 1, name: 'Plastic Warrior', icon: '🛡️', earned: true, description: 'Scanned 10 plastic items' },
  { id: 2, name: 'Upcycle Pro', icon: '♻️', earned: true, description: 'Completed 5 DIY projects' },
  { id: 3, name: 'Donation Star', icon: '⭐', earned: false, description: 'Donated 3 items' },
  { id: 4, name: 'Green Streak', icon: '🔥', earned: true, description: '7-day scanning streak' },
  { id: 5, name: 'Earth Saver', icon: '🌍', earned: false, description: 'Reach 100 eco points' },
  { id: 6, name: 'Community Hero', icon: '👥', earned: false, description: 'Help 10 community members' }
];

const levels = [
  { name: 'Eco Beginner', minPoints: 0, maxPoints: 24, color: '#10B981' },
  { name: 'Eco Explorer', minPoints: 25, maxPoints: 99, color: '#3B82F6' },
  { name: 'Eco Hero', minPoints: 100, maxPoints: 249, color: '#8B5CF6' },
  { name: 'Earth Saver', minPoints: 250, maxPoints: 999, color: '#F59E0B' }
];

export default function SettingsScreen() {
  const insets = useSafeAreaInsets();
  const [isDarkMode, setIsDarkMode] = useState(false);
  const [isMinimalMode, setIsMinimalMode] = useState(false);

  const currentLevel = levels.find(level => 
    userData.totalPoints >= level.minPoints && userData.totalPoints <= level.maxPoints
  );
  
  const nextLevel = levels.find(level => level.minPoints > userData.totalPoints);
  const progressToNext = nextLevel ? 
    ((userData.totalPoints - currentLevel.minPoints) / (nextLevel.minPoints - currentLevel.minPoints)) * 100 : 100;

  const earnedBadges = badges.filter(badge => badge.earned);

  return (
    <View style={{ flex: 1, backgroundColor: '#F0FDF4' }}>
      <StatusBar style="dark" />
      
      {/* Header */}
      <View style={{ 
        paddingTop: insets.top + 20,
        paddingBottom: 20,
        paddingHorizontal: 20,
        backgroundColor: '#4ADE80',
      }}>
        <Text style={{ 
          fontSize: 28, 
          fontWeight: 'bold', 
          color: 'white',
          marginBottom: 8
        }}>
          Settings ⚙️
        </Text>
        
        {/* User profile card */}
        <View style={{
          backgroundColor: 'white',
          padding: 20,
          borderRadius: 20,
          marginTop: 15,
          shadowColor: '#000',
          shadowOffset: { width: 0, height: 2 },
          shadowOpacity: 0.1,
          shadowRadius: 8,
          elevation: 3,
        }}>
          <View style={{
            flexDirection: 'row',
            alignItems: 'center',
            marginBottom: 15
          }}>
            <View style={{
              width: 60,
              height: 60,
              backgroundColor: '#4ADE80',
              borderRadius: 30,
              justifyContent: 'center',
              alignItems: 'center',
              marginRight: 15
            }}>
              <User size={30} color="white" />
            </View>
            <View style={{ flex: 1 }}>
              <Text style={{
                fontSize: 20,
                fontWeight: 'bold',
                color: '#1F2937',
                marginBottom: 4
              }}>
                {userData.name}
              </Text>
              <Text style={{
                fontSize: 14,
                color: '#6B7280'
              }}>
                {userData.email}
              </Text>
            </View>
          </View>
          
          {/* Impact stats */}
          <View style={{
            backgroundColor: '#F9FAFB',
            padding: 15,
            borderRadius: 12
          }}>
            <Text style={{
              fontSize: 14,
              fontWeight: '600',
              color: '#374151',
              marginBottom: 8
            }}>
              Your Impact
            </Text>
            <Text style={{
              fontSize: 16,
              color: '#059669',
              fontWeight: '600'
            }}>
              {userData.totalImpact}
            </Text>
          </View>
        </View>
      </View>

      <ScrollView 
        style={{ flex: 1 }}
        contentContainerStyle={{ 
          paddingHorizontal: 20,
          paddingTop: 20,
          paddingBottom: insets.bottom + 100
        }}
        showsVerticalScrollIndicator={false}
      >
        {/* Level & Progress */}
        <View style={{
          backgroundColor: 'white',
          padding: 20,
          borderRadius: 16,
          marginBottom: 20,
          shadowColor: '#000',
          shadowOffset: { width: 0, height: 2 },
          shadowOpacity: 0.08,
          shadowRadius: 12,
          elevation: 3,
        }}>
          <View style={{
            flexDirection: 'row',
            alignItems: 'center',
            marginBottom: 15
          }}>
            <Trophy size={24} color={currentLevel.color} />
            <Text style={{
              fontSize: 18,
              fontWeight: '600',
              color: '#1F2937',
              marginLeft: 10
            }}>
              Level & Progress
            </Text>
          </View>
          
          <View style={{
            flexDirection: 'row',
            justifyContent: 'space-between',
            alignItems: 'center',
            marginBottom: 10
          }}>
            <Text style={{
              fontSize: 16,
              fontWeight: '600',
              color: currentLevel.color
            }}>
              {currentLevel.name}
            </Text>
            <Text style={{
              fontSize: 14,
              color: '#6B7280'
            }}>
              {userData.totalPoints} / {nextLevel ? nextLevel.minPoints : '∞'} points
            </Text>
          </View>
          
          <View style={{
            backgroundColor: '#F3F4F6',
            height: 8,
            borderRadius: 4,
            marginBottom: 15
          }}>
            <View style={{
              backgroundColor: currentLevel.color,
              height: 8,
              borderRadius: 4,
              width: `${progressToNext}%`
            }} />
          </View>
          
          <View style={{
            flexDirection: 'row',
            justifyContent: 'space-between'
          }}>
            <View style={{
              flexDirection: 'row',
              alignItems: 'center'
            }}>
              <Zap size={16} color="#4ADE80" />
              <Text style={{
                fontSize: 14,
                color: '#374151',
                marginLeft: 5
              }}>
                {userData.totalPoints} Eco Points
              </Text>
            </View>
            
            <View style={{
              flexDirection: 'row',
              alignItems: 'center'
            }}>
              <Flame size={16} color="#EF4444" />
              <Text style={{
                fontSize: 14,
                color: '#374151',
                marginLeft: 5
              }}>
                {userData.currentStreak} day streak
              </Text>
            </View>
          </View>
        </View>

        {/* Badges */}
        <View style={{
          backgroundColor: 'white',
          padding: 20,
          borderRadius: 16,
          marginBottom: 20,
          shadowColor: '#000',
          shadowOffset: { width: 0, height: 2 },
          shadowOpacity: 0.08,
          shadowRadius: 12,
          elevation: 3,
        }}>
          <View style={{
            flexDirection: 'row',
            alignItems: 'center',
            justifyContent: 'space-between',
            marginBottom: 15
          }}>
            <View style={{
              flexDirection: 'row',
              alignItems: 'center'
            }}>
              <Award size={24} color="#F59E0B" />
              <Text style={{
                fontSize: 18,
                fontWeight: '600',
                color: '#1F2937',
                marginLeft: 10
              }}>
                Badges
              </Text>
            </View>
            <Text style={{
              fontSize: 14,
              color: '#6B7280'
            }}>
              {earnedBadges.length}/{badges.length}
            </Text>
          </View>
          
          <View style={{
            flexDirection: 'row',
            flexWrap: 'wrap',
            gap: 10
          }}>
            {badges.map((badge) => (
              <View
                key={badge.id}
                style={{
                  backgroundColor: badge.earned ? '#ECFDF5' : '#F9FAFB',
                  padding: 12,
                  borderRadius: 12,
                  alignItems: 'center',
                  width: '30%',
                  opacity: badge.earned ? 1 : 0.5
                }}
              >
                <Text style={{ fontSize: 24, marginBottom: 5 }}>{badge.icon}</Text>
                <Text style={{
                  fontSize: 12,
                  fontWeight: '600',
                  color: badge.earned ? '#059669' : '#6B7280',
                  textAlign: 'center'
                }}>
                  {badge.name}
                </Text>
              </View>
            ))}
          </View>
        </View>

        {/* Theme Settings */}
        <View style={{
          backgroundColor: 'white',
          padding: 20,
          borderRadius: 16,
          marginBottom: 20,
          shadowColor: '#000',
          shadowOffset: { width: 0, height: 2 },
          shadowOpacity: 0.08,
          shadowRadius: 12,
          elevation: 3,
        }}>
          <View style={{
            flexDirection: 'row',
            alignItems: 'center',
            marginBottom: 20
          }}>
            <Palette size={24} color="#8B5CF6" />
            <Text style={{
              fontSize: 18,
              fontWeight: '600',
              color: '#1F2937',
              marginLeft: 10
            }}>
              Theme Settings
            </Text>
          </View>
          
          <View style={{
            flexDirection: 'row',
            justifyContent: 'space-between',
            alignItems: 'center',
            paddingVertical: 12,
            borderBottomWidth: 1,
            borderBottomColor: '#F3F4F6'
          }}>
            <View style={{
              flexDirection: 'row',
              alignItems: 'center'
            }}>
              <Moon size={20} color="#6B7280" />
              <Text style={{
                fontSize: 16,
                color: '#1F2937',
                marginLeft: 10
              }}>
                Dark Mode
              </Text>
            </View>
            <Switch
              value={isDarkMode}
              onValueChange={setIsDarkMode}
              trackColor={{ false: '#F3F4F6', true: '#4ADE80' }}
              thumbColor={isDarkMode ? '#FFFFFF' : '#FFFFFF'}
            />
          </View>
          
          <View style={{
            flexDirection: 'row',
            justifyContent: 'space-between',
            alignItems: 'center',
            paddingVertical: 12
          }}>
            <View style={{
              flexDirection: 'row',
              alignItems: 'center'
            }}>
              <Sparkles size={20} color="#6B7280" />
              <Text style={{
                fontSize: 16,
                color: '#1F2937',
                marginLeft: 10
              }}>
                Modern Minimal
              </Text>
            </View>
            <Switch
              value={isMinimalMode}
              onValueChange={setIsMinimalMode}
              trackColor={{ false: '#F3F4F6', true: '#4ADE80' }}
              thumbColor={isMinimalMode ? '#FFFFFF' : '#FFFFFF'}
            />
          </View>
          
          <View style={{
            backgroundColor: '#F0FDF4',
            padding: 12,
            borderRadius: 8,
            marginTop: 10
          }}>
            <Text style={{
              fontSize: 12,
              color: '#059669',
              textAlign: 'center'
            }}>
              Note: Pingpie stays cute in all themes! 🐧
            </Text>
          </View>
        </View>

        {/* Account Actions */}
        <View style={{
          backgroundColor: 'white',
          borderRadius: 16,
          marginBottom: 20,
          shadowColor: '#000',
          shadowOffset: { width: 0, height: 2 },
          shadowOpacity: 0.08,
          shadowRadius: 12,
          elevation: 3,
        }}>
          <TouchableOpacity
            style={{
              flexDirection: 'row',
              alignItems: 'center',
              justifyContent: 'space-between',
              padding: 20,
              borderBottomWidth: 1,
              borderBottomColor: '#F3F4F6'
            }}
            activeOpacity={0.7}
          >
            <View style={{
              flexDirection: 'row',
              alignItems: 'center'
            }}>
              <Target size={20} color="#6B7280" />
              <Text style={{
                fontSize: 16,
                color: '#1F2937',
                marginLeft: 10
              }}>
                Goals & Challenges
              </Text>
            </View>
            <ChevronRight size={20} color="#9CA3AF" />
          </TouchableOpacity>
          
          <TouchableOpacity
            style={{
              flexDirection: 'row',
              alignItems: 'center',
              justifyContent: 'space-between',
              padding: 20
            }}
            activeOpacity={0.7}
          >
            <View style={{
              flexDirection: 'row',
              alignItems: 'center'
            }}>
              <LogOut size={20} color="#EF4444" />
              <Text style={{
                fontSize: 16,
                color: '#EF4444',
                marginLeft: 10
              }}>
                Sign Out
              </Text>
            </View>
            <ChevronRight size={20} color="#9CA3AF" />
          </TouchableOpacity>
        </View>

        {/* App Info */}
        <View style={{
          backgroundColor: '#ECFDF5',
          padding: 20,
          borderRadius: 16,
          borderLeftWidth: 4,
          borderLeftColor: '#4ADE80'
        }}>
          <Text style={{
            fontSize: 16,
            fontWeight: '600',
            color: '#059669',
            marginBottom: 8
          }}>
            🐧 ECO PIE v1.0
          </Text>
          <Text style={{
            fontSize: 14,
            color: '#374151',
            lineHeight: 20
          }}>
            Saving the Earth, one scan at a time. Made with 💚 for our planet.
          </Text>
        </View>
      </ScrollView>
    </View>
  );
}