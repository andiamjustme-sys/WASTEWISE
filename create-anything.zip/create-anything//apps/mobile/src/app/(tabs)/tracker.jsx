import React from 'react';
import { View, Text, ScrollView, TouchableOpacity } from 'react-native';
import { StatusBar } from 'expo-status-bar';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Calendar, Recycle, Leaf, Zap } from 'lucide-react-native';

// Mock scan history data (in real app, this would come from database/storage)
const scanHistory = [
  {
    id: 1,
    item: 'Plastic bottle',
    type: 'Plastic',
    ecoPoints: 10,
    date: '2025-09-01',
    time: '14:30',
    thumbnail: '🍼'
  },
  {
    id: 2,
    item: 'Paper document',
    type: 'Paper',
    ecoPoints: 8,
    date: '2025-09-01',
    time: '12:15',
    thumbnail: '📄'
  },
  {
    id: 3,
    item: 'Food waste',
    type: 'Organic',
    ecoPoints: 12,
    date: '2025-08-31',
    time: '19:45',
    thumbnail: '🍎'
  },
  {
    id: 4,
    item: 'Electronic device',
    type: 'E-waste',
    ecoPoints: 25,
    date: '2025-08-31',
    time: '16:20',
    thumbnail: '📱'
  },
  {
    id: 5,
    item: 'Glass jar',
    type: 'Glass',
    ecoPoints: 15,
    date: '2025-08-30',
    time: '11:10',
    thumbnail: '🫙'
  },
  {
    id: 6,
    item: 'Aluminum can',
    type: 'Metal',
    ecoPoints: 18,
    date: '2025-08-30',
    time: '09:30',
    thumbnail: '🥤'
  }
];

const getTypeColor = (type) => {
  switch (type) {
    case 'Plastic': return '#EF4444';
    case 'Paper': return '#F59E0B';
    case 'Organic': return '#10B981';
    case 'E-waste': return '#8B5CF6';
    case 'Glass': return '#06B6D4';
    case 'Metal': return '#6B7280';
    default: return '#4ADE80';
  }
};

const formatDate = (dateString) => {
  const date = new Date(dateString);
  const today = new Date();
  const yesterday = new Date(today);
  yesterday.setDate(yesterday.getDate() - 1);
  
  if (date.toDateString() === today.toDateString()) {
    return 'Today';
  } else if (date.toDateString() === yesterday.toDateString()) {
    return 'Yesterday';
  } else {
    return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
  }
};

export default function TrackerScreen() {
  const insets = useSafeAreaInsets();
  
  const totalPoints = scanHistory.reduce((sum, scan) => sum + scan.ecoPoints, 0);
  const totalScans = scanHistory.length;
  const todayScans = scanHistory.filter(scan => 
    new Date(scan.date).toDateString() === new Date().toDateString()
  ).length;

  return (
    <View style={{ flex: 1, backgroundColor: '#F0FDF4' }}>
      <StatusBar style="dark" />
      
      {/* Header */}
      <View style={{ 
        paddingTop: insets.top + 20,
        paddingBottom: 20,
        paddingHorizontal: 20,
        backgroundColor: '#4ADE80',
      }}>
        <Text style={{ 
          fontSize: 28, 
          fontWeight: 'bold', 
          color: 'white',
          marginBottom: 8
        }}>
          Your Eco Tracker 📊
        </Text>
        
        {/* Stats cards */}
        <View style={{
          flexDirection: 'row',
          justifyContent: 'space-between',
          marginTop: 15
        }}>
          <View style={{
            backgroundColor: 'white',
            padding: 15,
            borderRadius: 12,
            flex: 1,
            marginRight: 8,
            alignItems: 'center'
          }}>
            <Zap size={24} color="#4ADE80" />
            <Text style={{
              fontSize: 20,
              fontWeight: 'bold',
              color: '#1F2937',
              marginTop: 5
            }}>
              {totalPoints}
            </Text>
            <Text style={{
              fontSize: 12,
              color: '#6B7280',
              textAlign: 'center'
            }}>
              Eco Points
            </Text>
          </View>
          
          <View style={{
            backgroundColor: 'white',
            padding: 15,
            borderRadius: 12,
            flex: 1,
            marginHorizontal: 4,
            alignItems: 'center'
          }}>
            <Recycle size={24} color="#4ADE80" />
            <Text style={{
              fontSize: 20,
              fontWeight: 'bold',
              color: '#1F2937',
              marginTop: 5
            }}>
              {totalScans}
            </Text>
            <Text style={{
              fontSize: 12,
              color: '#6B7280',
              textAlign: 'center'
            }}>
              Total Scans
            </Text>
          </View>
          
          <View style={{
            backgroundColor: 'white',
            padding: 15,
            borderRadius: 12,
            flex: 1,
            marginLeft: 8,
            alignItems: 'center'
          }}>
            <Calendar size={24} color="#4ADE80" />
            <Text style={{
              fontSize: 20,
              fontWeight: 'bold',
              color: '#1F2937',
              marginTop: 5
            }}>
              {todayScans}
            </Text>
            <Text style={{
              fontSize: 12,
              color: '#6B7280',
              textAlign: 'center'
            }}>
              Today
            </Text>
          </View>
        </View>
      </View>

      {/* Scan History */}
      <ScrollView 
        style={{ flex: 1 }}
        contentContainerStyle={{ 
          paddingHorizontal: 20,
          paddingTop: 20,
          paddingBottom: insets.bottom + 100
        }}
        showsVerticalScrollIndicator={false}
      >
        <View style={{
          flexDirection: 'row',
          alignItems: 'center',
          marginBottom: 20
        }}>
          <Text style={{
            fontSize: 20,
            fontWeight: 'bold',
            color: '#1F2937',
            flex: 1
          }}>
            📋 Scan History
          </Text>
          <View style={{
            backgroundColor: '#ECFDF5',
            paddingHorizontal: 12,
            paddingVertical: 6,
            borderRadius: 20
          }}>
            <Text style={{
              fontSize: 12,
              color: '#059669',
              fontWeight: '600'
            }}>
              {totalScans} items tracked
            </Text>
          </View>
        </View>

        {scanHistory.length === 0 ? (
          <View style={{
            backgroundColor: 'white',
            padding: 40,
            borderRadius: 16,
            alignItems: 'center',
            shadowColor: '#000',
            shadowOffset: { width: 0, height: 2 },
            shadowOpacity: 0.08,
            shadowRadius: 12,
            elevation: 3,
          }}>
            <Text style={{ fontSize: 60, marginBottom: 15 }}>🐧</Text>
            <Text style={{
              fontSize: 18,
              fontWeight: '600',
              color: '#1F2937',
              marginBottom: 8,
              textAlign: 'center'
            }}>
              No scans yet!
            </Text>
            <Text style={{
              fontSize: 14,
              color: '#6B7280',
              textAlign: 'center',
              lineHeight: 20
            }}>
              Start scanning items to track your eco impact and earn points!
            </Text>
          </View>
        ) : (
          scanHistory.map((scan) => (
            <TouchableOpacity
              key={scan.id}
              style={{
                backgroundColor: 'white',
                padding: 16,
                borderRadius: 12,
                marginBottom: 12,
                shadowColor: '#000',
                shadowOffset: { width: 0, height: 1 },
                shadowOpacity: 0.05,
                shadowRadius: 8,
                elevation: 2,
              }}
              activeOpacity={0.7}
            >
              <View style={{
                flexDirection: 'row',
                alignItems: 'center'
              }}>
                {/* Thumbnail */}
                <View style={{
                  width: 50,
                  height: 50,
                  backgroundColor: '#F9FAFB',
                  borderRadius: 8,
                  justifyContent: 'center',
                  alignItems: 'center',
                  marginRight: 15
                }}>
                  <Text style={{ fontSize: 24 }}>{scan.thumbnail}</Text>
                </View>
                
                {/* Item details */}
                <View style={{ flex: 1 }}>
                  <Text style={{
                    fontSize: 16,
                    fontWeight: '600',
                    color: '#1F2937',
                    marginBottom: 4
                  }}>
                    {scan.item}
                  </Text>
                  
                  <View style={{
                    flexDirection: 'row',
                    alignItems: 'center',
                    marginBottom: 4
                  }}>
                    <View style={{
                      backgroundColor: getTypeColor(scan.type),
                      paddingHorizontal: 8,
                      paddingVertical: 2,
                      borderRadius: 10,
                      marginRight: 8
                    }}>
                      <Text style={{
                        fontSize: 10,
                        color: 'white',
                        fontWeight: '600'
                      }}>
                        {scan.type}
                      </Text>
                    </View>
                    
                    <Text style={{
                      fontSize: 12,
                      color: '#6B7280'
                    }}>
                      {formatDate(scan.date)} • {scan.time}
                    </Text>
                  </View>
                </View>
                
                {/* Points */}
                <View style={{
                  alignItems: 'center'
                }}>
                  <View style={{
                    backgroundColor: '#ECFDF5',
                    paddingHorizontal: 8,
                    paddingVertical: 4,
                    borderRadius: 8,
                    flexDirection: 'row',
                    alignItems: 'center'
                  }}>
                    <Leaf size={12} color="#059669" />
                    <Text style={{
                      fontSize: 12,
                      color: '#059669',
                      fontWeight: '600',
                      marginLeft: 4
                    }}>
                      +{scan.ecoPoints}
                    </Text>
                  </View>
                </View>
              </View>
            </TouchableOpacity>
          ))
        )}

        {/* Encouragement message */}
        {scanHistory.length > 0 && (
          <View style={{
            backgroundColor: '#ECFDF5',
            padding: 20,
            borderRadius: 16,
            marginTop: 10,
            borderLeftWidth: 4,
            borderLeftColor: '#4ADE80'
          }}>
            <Text style={{
              fontSize: 16,
              fontWeight: '600',
              color: '#059669',
              marginBottom: 8
            }}>
              🎉 Amazing Progress!
            </Text>
            <Text style={{
              fontSize: 14,
              color: '#374151',
              lineHeight: 20
            }}>
              You've made a real difference! Keep scanning to earn more points and help save our planet.
            </Text>
          </View>
        )}
      </ScrollView>
    </View>
  );
}