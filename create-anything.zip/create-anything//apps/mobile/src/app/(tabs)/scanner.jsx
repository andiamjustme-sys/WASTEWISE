import React, { useState, useRef } from 'react';
import { View, Text, TouchableOpacity, Alert, Linking } from 'react-native';
import { StatusBar } from 'expo-status-bar';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { CameraView, useCameraPermissions } from 'expo-camera';
import * as ImagePicker from 'expo-image-picker';
import { 
  Camera, 
  Zap, 
  ZapOff, 
  RotateCcw, 
  Image as ImageIcon,
  ExternalLink,
  Youtube,
  Search,
  CheckCircle
} from 'lucide-react-native';

// Simulated AI classification (in real app, this would use TensorFlow Lite)
const classifyItem = async (imageUri) => {
  // Simulate processing delay
  await new Promise(resolve => setTimeout(resolve, 2000));
  
  // Random classification for demo (replace with actual AI)
  const categories = [
    { 
      type: 'Plastic', 
      item: 'Plastic bottle',
      disposal: 'Clean and place in recycling bin',
      searchQuery: 'plastic recycling near me',
      diyQuery: 'diy plastic bottle crafts',
      factsQuery: 'plastic waste environmental facts'
    },
    { 
      type: 'Paper', 
      item: 'Paper document',
      disposal: 'Remove any plastic parts and recycle',
      searchQuery: 'paper recycling center near me',
      diyQuery: 'diy paper crafts ideas',
      factsQuery: 'paper recycling environmental benefits'
    },
    { 
      type: 'Organic', 
      item: 'Food waste',
      disposal: 'Compost or dispose in organic waste bin',
      searchQuery: 'composting near me',
      diyQuery: 'home composting tutorial',
      factsQuery: 'food waste environmental impact'
    },
    { 
      type: 'E-waste', 
      item: 'Electronic device',
      disposal: 'Take to certified e-waste recycling center',
      searchQuery: 'e-waste recycling near me',
      diyQuery: 'electronic parts upcycling',
      factsQuery: 'electronic waste pollution facts'
    }
  ];
  
  return categories[Math.floor(Math.random() * categories.length)];
};

const loadingQuotes = [
  "You are the change 🌍",
  "Small actions, big impact ✨",
  "Saving the Earth, one scan at a time 🐧",
  "Every choice matters 💚",
  "Building a better tomorrow 🌱"
];

export default function ScannerScreen() {
  const insets = useSafeAreaInsets();
  const [permission, requestPermission] = useCameraPermissions();
  const [flashMode, setFlashMode] = useState('off');
  const [facing, setFacing] = useState('back');
  const [isProcessing, setIsProcessing] = useState(false);
  const [result, setResult] = useState(null);
  const [currentQuote, setCurrentQuote] = useState(0);
  const cameraRef = useRef(null);

  React.useEffect(() => {
    if (isProcessing) {
      const interval = setInterval(() => {
        setCurrentQuote((prev) => (prev + 1) % loadingQuotes.length);
      }, 1000);
      return () => clearInterval(interval);
    }
  }, [isProcessing]);

  const takePicture = async () => {
    if (!cameraRef.current) return;
    
    try {
      setIsProcessing(true);
      setResult(null);
      
      const photo = await cameraRef.current.takePictureAsync({
        quality: 0.8,
        base64: false,
      });
      
      // Classify the image
      const classification = await classifyItem(photo.uri);
      setResult(classification);
      
    } catch (error) {
      console.error('Error taking picture:', error);
      Alert.alert('Error', 'Failed to take picture. Please try again.');
    } finally {
      setIsProcessing(false);
    }
  };

  const pickFromGallery = async () => {
    try {
      const result = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: ImagePicker.MediaTypeOptions.Images,
        allowsEditing: true,
        aspect: [1, 1],
        quality: 0.8,
      });

      if (!result.canceled) {
        setIsProcessing(true);
        setResult(null);
        
        const classification = await classifyItem(result.assets[0].uri);
        setResult(classification);
        setIsProcessing(false);
      }
    } catch (error) {
      console.error('Error picking image:', error);
      setIsProcessing(false);
    }
  };

  const openLink = async (query, platform = 'search') => {
    try {
      let url;
      if (platform === 'youtube') {
        url = `https://www.youtube.com/results?search_query=${encodeURIComponent(query)}`;
      } else {
        url = `https://www.google.com/search?q=${encodeURIComponent(query)}`;
      }
      await Linking.openURL(url);
    } catch (error) {
      console.error('Failed to open link:', error);
    }
  };

  const resetScan = () => {
    setResult(null);
    setIsProcessing(false);
  };

  if (!permission) {
    return <View style={{ flex: 1, backgroundColor: '#F0FDF4' }} />;
  }

  if (!permission.granted) {
    return (
      <View style={{ 
        flex: 1, 
        backgroundColor: '#F0FDF4',
        justifyContent: 'center',
        alignItems: 'center',
        paddingHorizontal: 20
      }}>
        <StatusBar style="dark" />
        <Text style={{ fontSize: 30, marginBottom: 20 }}>🐧</Text>
        <Text style={{ 
          fontSize: 18, 
          textAlign: 'center',
          color: '#374151',
          marginBottom: 20,
          lineHeight: 24
        }}>
          Pingpie needs camera access to help you scan items and save the planet!
        </Text>
        <TouchableOpacity
          onPress={requestPermission}
          style={{
            backgroundColor: '#4ADE80',
            paddingHorizontal: 30,
            paddingVertical: 15,
            borderRadius: 25,
          }}
        >
          <Text style={{
            color: 'white',
            fontSize: 16,
            fontWeight: '600'
          }}>
            Grant Camera Permission
          </Text>
        </TouchableOpacity>
      </View>
    );
  }

  if (isProcessing) {
    return (
      <View style={{ 
        flex: 1, 
        backgroundColor: '#4ADE80',
        justifyContent: 'center',
        alignItems: 'center',
        paddingTop: insets.top
      }}>
        <StatusBar style="light" />
        <Text style={{ fontSize: 60, marginBottom: 20 }}>🐧</Text>
        <Text style={{
          fontSize: 24,
          color: 'white',
          fontWeight: 'bold',
          marginBottom: 10
        }}>
          Analyzing...
        </Text>
        <Text style={{
          fontSize: 16,
          color: 'white',
          textAlign: 'center',
          paddingHorizontal: 40
        }}>
          {loadingQuotes[currentQuote]}
        </Text>
      </View>
    );
  }

  if (result) {
    return (
      <View style={{ 
        flex: 1, 
        backgroundColor: '#F0FDF4',
        paddingTop: insets.top + 20
      }}>
        <StatusBar style="dark" />
        
        {/* Header */}
        <View style={{ 
          paddingHorizontal: 20,
          marginBottom: 30,
          alignItems: 'center'
        }}>
          <CheckCircle size={60} color="#4ADE80" />
          <Text style={{
            fontSize: 24,
            fontWeight: 'bold',
            color: '#1F2937',
            marginTop: 15,
            textAlign: 'center'
          }}>
            Great job! 🎉
          </Text>
          <Text style={{
            fontSize: 16,
            color: '#6B7280',
            textAlign: 'center',
            marginTop: 5
          }}>
            Pingpie found: {result.item}
          </Text>
        </View>

        {/* Results */}
        <View style={{ flex: 1, paddingHorizontal: 20 }}>
          {/* What it is */}
          <View style={{
            backgroundColor: 'white',
            padding: 20,
            borderRadius: 16,
            marginBottom: 16,
            shadowColor: '#000',
            shadowOffset: { width: 0, height: 2 },
            shadowOpacity: 0.08,
            shadowRadius: 12,
            elevation: 3,
          }}>
            <Text style={{
              fontSize: 14,
              color: '#059669',
              fontWeight: '600',
              marginBottom: 8
            }}>
              📝 WHAT IT IS
            </Text>
            <Text style={{
              fontSize: 18,
              color: '#1F2937',
              fontWeight: '600'
            }}>
              {result.item} ({result.type})
            </Text>
          </View>

          {/* What to do */}
          <View style={{
            backgroundColor: 'white',
            padding: 20,
            borderRadius: 16,
            marginBottom: 16,
            shadowColor: '#000',
            shadowOffset: { width: 0, height: 2 },
            shadowOpacity: 0.08,
            shadowRadius: 12,
            elevation: 3,
          }}>
            <Text style={{
              fontSize: 14,
              color: '#059669',
              fontWeight: '600',
              marginBottom: 8
            }}>
              🚮 WHAT TO DO
            </Text>
            <Text style={{
              fontSize: 16,
              color: '#1F2937',
              lineHeight: 22
            }}>
              {result.disposal}
            </Text>
          </View>

          {/* Action links */}
          <View style={{
            backgroundColor: 'white',
            padding: 20,
            borderRadius: 16,
            marginBottom: 20,
            shadowColor: '#000',
            shadowOffset: { width: 0, height: 2 },
            shadowOpacity: 0.08,
            shadowRadius: 12,
            elevation: 3,
          }}>
            <Text style={{
              fontSize: 14,
              color: '#059669',
              fontWeight: '600',
              marginBottom: 15
            }}>
              🔎 HELPFUL LINKS
            </Text>
            
            <TouchableOpacity
              style={{
                flexDirection: 'row',
                alignItems: 'center',
                paddingVertical: 12,
                borderBottomWidth: 1,
                borderBottomColor: '#F3F4F6'
              }}
              onPress={() => openLink(result.searchQuery)}
            >
              <Search size={20} color="#4ADE80" />
              <Text style={{
                flex: 1,
                marginLeft: 12,
                fontSize: 16,
                color: '#1F2937'
              }}>
                Find disposal locations near me
              </Text>
              <ExternalLink size={16} color="#9CA3AF" />
            </TouchableOpacity>

            <TouchableOpacity
              style={{
                flexDirection: 'row',
                alignItems: 'center',
                paddingVertical: 12,
                borderBottomWidth: 1,
                borderBottomColor: '#F3F4F6'
              }}
              onPress={() => openLink(result.diyQuery, 'youtube')}
            >
              <Youtube size={20} color="#EF4444" />
              <Text style={{
                flex: 1,
                marginLeft: 12,
                fontSize: 16,
                color: '#1F2937'
              }}>
                DIY upcycling ideas
              </Text>
              <ExternalLink size={16} color="#9CA3AF" />
            </TouchableOpacity>

            <TouchableOpacity
              style={{
                flexDirection: 'row',
                alignItems: 'center',
                paddingVertical: 12
              }}
              onPress={() => openLink(result.factsQuery)}
            >
              <Search size={20} color="#4ADE80" />
              <Text style={{
                flex: 1,
                marginLeft: 12,
                fontSize: 16,
                color: '#1F2937'
              }}>
                Learn environmental facts
              </Text>
              <ExternalLink size={16} color="#9CA3AF" />
            </TouchableOpacity>
          </View>
        </View>

        {/* Action buttons */}
        <View style={{
          paddingHorizontal: 20,
          paddingBottom: insets.bottom + 20
        }}>
          <TouchableOpacity
            style={{
              backgroundColor: '#4ADE80',
              paddingVertical: 16,
              borderRadius: 25,
              marginBottom: 12
            }}
            onPress={resetScan}
          >
            <Text style={{
              color: 'white',
              fontSize: 18,
              fontWeight: '600',
              textAlign: 'center'
            }}>
              Scan Another Item 📸
            </Text>
          </TouchableOpacity>
        </View>
      </View>
    );
  }

  return (
    <View style={{ flex: 1, backgroundColor: 'black' }}>
      <StatusBar style="light" />
      
      <CameraView
        style={{ flex: 1 }}
        facing={facing}
        flash={flashMode}
        ref={cameraRef}
      >
        {/* Top controls */}
        <View style={{
          paddingTop: insets.top + 20,
          paddingHorizontal: 20,
          flexDirection: 'row',
          justifyContent: 'space-between',
          alignItems: 'center'
        }}>
          <TouchableOpacity
            onPress={() => setFlashMode(flashMode === 'off' ? 'on' : 'off')}
            style={{
              backgroundColor: 'rgba(0,0,0,0.6)',
              padding: 12,
              borderRadius: 20
            }}
          >
            {flashMode === 'off' ? 
              <ZapOff size={24} color="white" /> : 
              <Zap size={24} color="white" />
            }
          </TouchableOpacity>

          <TouchableOpacity
            onPress={() => setFacing(facing === 'back' ? 'front' : 'back')}
            style={{
              backgroundColor: 'rgba(0,0,0,0.6)',
              padding: 12,
              borderRadius: 20
            }}
          >
            <RotateCcw size={24} color="white" />
          </TouchableOpacity>
        </View>

        {/* Center guidance */}
        <View style={{
          flex: 1,
          justifyContent: 'center',
          alignItems: 'center',
          paddingHorizontal: 40
        }}>
          <View style={{
            backgroundColor: 'rgba(0,0,0,0.7)',
            padding: 20,
            borderRadius: 20,
            alignItems: 'center'
          }}>
            <Text style={{ fontSize: 30, marginBottom: 10 }}>🐧</Text>
            <Text style={{
              color: 'white',
              fontSize: 18,
              fontWeight: '600',
              textAlign: 'center',
              marginBottom: 8
            }}>
              Point at any item
            </Text>
            <Text style={{
              color: 'rgba(255,255,255,0.8)',
              fontSize: 14,
              textAlign: 'center'
            }}>
              Pingpie will help you dispose of it responsibly
            </Text>
          </View>
        </View>

        {/* Bottom controls */}
        <View style={{
          paddingBottom: insets.bottom + 40,
          paddingHorizontal: 40,
          flexDirection: 'row',
          justifyContent: 'center',
          alignItems: 'center'
        }}>
          <TouchableOpacity
            onPress={pickFromGallery}
            style={{
              backgroundColor: 'rgba(255,255,255,0.2)',
              padding: 16,
              borderRadius: 20,
              marginRight: 30
            }}
          >
            <ImageIcon size={28} color="white" />
          </TouchableOpacity>

          <TouchableOpacity
            onPress={takePicture}
            style={{
              backgroundColor: '#4ADE80',
              width: 80,
              height: 80,
              borderRadius: 40,
              justifyContent: 'center',
              alignItems: 'center',
              shadowColor: '#4ADE80',
              shadowOffset: { width: 0, height: 4 },
              shadowOpacity: 0.4,
              shadowRadius: 12,
              elevation: 8,
            }}
          >
            <Camera size={36} color="white" />
          </TouchableOpacity>

          <View style={{ width: 74, marginLeft: 30 }} />
        </View>
      </CameraView>
    </View>
  );
}