import React, { useState, useEffect } from 'react';
import { View, Text, ScrollView, TouchableOpacity, Linking } from 'react-native';
import { StatusBar } from 'expo-status-bar';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Sparkles, ExternalLink } from 'lucide-react-native';

const articles = [
  {
    id: 1,
    title: "5 Easy Ways to Reduce Plastic Waste",
    category: "♻️ Recycling Tips",
    link: "https://www.google.com/search?q=5+ways+reduce+plastic+waste+tips"
  },
  {
    id: 2,
    title: "DIY: Turn Old T-Shirts into Reusable Bags",
    category: "🎥 DIY Craft Ideas",
    link: "https://www.youtube.com/results?search_query=diy+tshirt+reusable+bags"
  },
  {
    id: 3,
    title: "Climate Change: What's Happening Now?",
    category: "📰 Climate News Today",
    link: "https://www.google.com/search?q=climate+change+news+today"
  },
  {
    id: 4,
    title: "Amazing Facts About Ocean Plastic",
    category: "🧠 Fun Environmental Facts",
    link: "https://www.google.com/search?q=ocean+plastic+pollution+facts"
  },
  {
    id: 5,
    title: "How to Start Composting at Home",
    category: "♻️ Recycling Tips",
    link: "https://www.youtube.com/results?search_query=how+to+start+composting+at+home"
  }
];

const pingpieTips = [
  "New article added just for you! 🐧",
  "Wanna see how plastic can become art? ✨",
  "You're doing amazing at saving our planet! 🌍",
  "Every scan makes a difference! Keep going! 💪"
];

export default function HomeScreen() {
  const insets = useSafeAreaInsets();
  const [currentTip, setCurrentTip] = useState(0);
  
  // Get user name - for now using static, later connect to auth
  const userName = "Emily";

  useEffect(() => {
    // Rotate Pingpie tips every 5 seconds
    const interval = setInterval(() => {
      setCurrentTip((prev) => (prev + 1) % pingpieTips.length);
    }, 5000);
    
    return () => clearInterval(interval);
  }, []);

  const openLink = async (url) => {
    try {
      await Linking.openURL(url);
    } catch (error) {
      console.error('Failed to open link:', error);
    }
  };

  return (
    <View style={{ flex: 1, backgroundColor: '#F0FDF4' }}>
      <StatusBar style="dark" />
      
      {/* Header with personalized greeting */}
      <View style={{ 
        paddingTop: insets.top + 20,
        paddingBottom: 20,
        paddingHorizontal: 20,
        backgroundColor: '#4ADE80',
      }}>
        <Text style={{ 
          fontSize: 28, 
          fontWeight: 'bold', 
          color: 'white',
          marginBottom: 8
        }}>
          Hey, {userName}! 👋
        </Text>
        
        {/* Pingpie tip bubble */}
        <View style={{
          backgroundColor: 'white',
          padding: 15,
          borderRadius: 20,
          flexDirection: 'row',
          alignItems: 'center',
          shadowColor: '#000',
          shadowOffset: { width: 0, height: 2 },
          shadowOpacity: 0.1,
          shadowRadius: 8,
          elevation: 3,
        }}>
          <Text style={{ fontSize: 30, marginRight: 10 }}>🐧</Text>
          <View style={{ flex: 1 }}>
            <Text style={{ 
              fontSize: 14, 
              color: '#374151',
              fontWeight: '500'
            }}>
              Pingpie says:
            </Text>
            <Text style={{ 
              fontSize: 16, 
              color: '#1F2937',
              marginTop: 2
            }}>
              {pingpieTips[currentTip]}
            </Text>
          </View>
          <Sparkles size={20} color="#4ADE80" />
        </View>
      </View>

      {/* Content Feed */}
      <ScrollView 
        style={{ flex: 1 }}
        contentContainerStyle={{ 
          paddingHorizontal: 20,
          paddingTop: 20,
          paddingBottom: insets.bottom + 100
        }}
        showsVerticalScrollIndicator={false}
      >
        <Text style={{
          fontSize: 20,
          fontWeight: 'bold',
          color: '#1F2937',
          marginBottom: 20
        }}>
          📚 Your Eco Learning Feed
        </Text>

        {articles.map((article) => (
          <TouchableOpacity
            key={article.id}
            style={{
              backgroundColor: 'white',
              padding: 20,
              borderRadius: 16,
              marginBottom: 16,
              shadowColor: '#000',
              shadowOffset: { width: 0, height: 2 },
              shadowOpacity: 0.08,
              shadowRadius: 12,
              elevation: 3,
            }}
            onPress={() => openLink(article.link)}
            activeOpacity={0.7}
          >
            <View style={{ 
              flexDirection: 'row', 
              justifyContent: 'space-between',
              alignItems: 'flex-start',
              marginBottom: 8
            }}>
              <Text style={{
                fontSize: 12,
                color: '#059669',
                fontWeight: '600',
                textTransform: 'uppercase',
                flex: 1
              }}>
                {article.category}
              </Text>
              <ExternalLink size={16} color="#9CA3AF" />
            </View>
            
            <Text style={{
              fontSize: 18,
              fontWeight: '600',
              color: '#1F2937',
              lineHeight: 24
            }}>
              {article.title}
            </Text>
          </TouchableOpacity>
        ))}

        {/* Encouragement section */}
        <View style={{
          backgroundColor: '#ECFDF5',
          padding: 20,
          borderRadius: 16,
          marginTop: 10,
          borderLeftWidth: 4,
          borderLeftColor: '#4ADE80'
        }}>
          <Text style={{
            fontSize: 16,
            fontWeight: '600',
            color: '#059669',
            marginBottom: 8
          }}>
            🌱 Keep Growing!
          </Text>
          <Text style={{
            fontSize: 14,
            color: '#374151',
            lineHeight: 20
          }}>
            Every small action you take helps our planet. Ready to scan your next item?
          </Text>
        </View>
      </ScrollView>
    </View>
  );
}