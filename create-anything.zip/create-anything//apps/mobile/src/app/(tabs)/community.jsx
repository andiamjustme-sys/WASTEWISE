import React, { useState } from "react";
import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  Linking,
} from "react-native";
import { StatusBar } from "expo-status-bar";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import {
  MessageCircle,
  Send,
  Instagram,
  ExternalLink,
  Users,
  Heart,
  MapPin,
  Calendar,
  Clock,
  Leaf,
  Recycle,
  TreePine,
  Waves,
} from "lucide-react-native";

const communityLinks = [
  {
    id: 1,
    title: "WhatsApp Group",
    description:
      "Join our eco-warriors community for daily tips and challenges",
    icon: MessageCircle,
    color: "#25D366",
    url: "https://whatsapp.com/channel/0029VaAqUub9Hw8vTfpk2v1A",
    members: "2.3k members",
  },
  {
    id: 2,
    title: "Telegram Channel",
    description: "Get instant updates on environmental news and events",
    icon: Send,
    color: "#0088CC",
    url: "https://t.me/ecopie_community",
    members: "1.8k subscribers",
  },
  {
    id: 3,
    title: "Instagram Page",
    description: "Follow us for inspiring eco-content and success stories",
    icon: Instagram,
    color: "#E4405F",
    url: "https://instagram.com/ecopie_app",
    members: "5.2k followers",
  },
];

// Local events data
const localEvents = [
  {
    id: 1,
    title: "Beach Cleanup Drive",
    organization: "Ocean Warriors",
    date: "2025-09-15",
    time: "09:00 AM",
    location: "Santa Monica Beach, CA",
    distance: "2.3 miles away",
    participants: 45,
    maxParticipants: 60,
    type: "cleanup",
    icon: Waves,
    color: "#06B6D4",
    description:
      "Join us for a morning beach cleanup! Bring gloves and water bottle.",
    url: "https://www.google.com/search?q=beach+cleanup+santa+monica",
  },
  {
    id: 2,
    title: "Community Garden Planting",
    organization: "Green Thumbs Society",
    date: "2025-09-12",
    time: "10:00 AM",
    location: "Central Park Community Garden",
    distance: "1.8 miles away",
    participants: 23,
    maxParticipants: 30,
    type: "planting",
    icon: TreePine,
    color: "#10B981",
    description: "Help us plant vegetables and herbs for the community garden.",
    url: "https://www.google.com/search?q=community+garden+volunteer+central+park",
  },
  {
    id: 3,
    title: "Recycling Workshop",
    organization: "Eco Education Hub",
    date: "2025-09-18",
    time: "02:00 PM",
    location: "City Library - Main Branch",
    distance: "0.7 miles away",
    participants: 12,
    maxParticipants: 25,
    type: "education",
    icon: Recycle,
    color: "#8B5CF6",
    description:
      "Learn creative ways to upcycle household items into useful crafts.",
    url: "https://www.google.com/search?q=recycling+workshop+city+library",
  },
];

const eventTypes = [
  { key: "all", label: "All Events", icon: "🌍" },
  { key: "cleanup", label: "Cleanup", icon: "🧹" },
  { key: "planting", label: "Planting", icon: "🌱" },
  { key: "education", label: "Education", icon: "📚" },
];

const upcomingFeatures = [
  {
    title: "User Posts & Photos",
    description: "Share your eco-journey with the community",
    icon: "📸",
  },
  {
    title: "Comments & Likes",
    description: "Engage with fellow eco-warriors",
    icon: "💬",
  },
  {
    title: "Daily Challenges",
    description: "Complete eco-challenges with friends",
    icon: "🏆",
  },
  {
    title: "Leaderboards",
    description: "Compete with eco-warriors worldwide",
    icon: "🏅",
  },
];

export default function CommunityScreen() {
  const insets = useSafeAreaInsets();
  const [selectedFilter, setSelectedFilter] = useState("all");

  const filteredEvents =
    selectedFilter === "all"
      ? localEvents
      : localEvents.filter((event) => event.type === selectedFilter);

  const openLink = async (url) => {
    try {
      await Linking.openURL(url);
    } catch (error) {
      console.error("Failed to open link:", error);
    }
  };

  const formatDate = (dateString) => {
    const date = new Date(dateString);
    const today = new Date();
    const tomorrow = new Date(today);
    tomorrow.setDate(tomorrow.getDate() + 1);

    if (date.toDateString() === today.toDateString()) {
      return "Today";
    } else if (date.toDateString() === tomorrow.toDateString()) {
      return "Tomorrow";
    } else {
      return date.toLocaleDateString("en-US", {
        weekday: "short",
        month: "short",
        day: "numeric",
      });
    }
  };

  return (
    <View style={{ flex: 1, backgroundColor: "#F0FDF4" }}>
      <StatusBar style="dark" />

      {/* Header */}
      <View
        style={{
          paddingTop: insets.top + 20,
          paddingBottom: 20,
          paddingHorizontal: 20,
          backgroundColor: "#4ADE80",
        }}
      >
        <Text
          style={{
            fontSize: 28,
            fontWeight: "bold",
            color: "white",
            marginBottom: 8,
          }}
        >
          Eco Community 🌍
        </Text>

        {/* Pingpie community message */}
        <View
          style={{
            backgroundColor: "white",
            padding: 15,
            borderRadius: 20,
            flexDirection: "row",
            alignItems: "center",
            marginTop: 15,
            shadowColor: "#000",
            shadowOffset: { width: 0, height: 2 },
            shadowOpacity: 0.1,
            shadowRadius: 8,
            elevation: 3,
          }}
        >
          <Text style={{ fontSize: 30, marginRight: 10 }}>🐧</Text>
          <View style={{ flex: 1 }}>
            <Text
              style={{
                fontSize: 14,
                color: "#374151",
                fontWeight: "500",
              }}
            >
              Pingpie says:
            </Text>
            <Text
              style={{
                fontSize: 16,
                color: "#1F2937",
                marginTop: 2,
              }}
            >
              Connect with eco-warriors worldwide! 🌱
            </Text>
          </View>
          <Users size={20} color="#4ADE80" />
        </View>
      </View>

      <ScrollView
        style={{ flex: 1 }}
        contentContainerStyle={{
          paddingHorizontal: 20,
          paddingTop: 20,
          paddingBottom: insets.bottom + 100,
        }}
        showsVerticalScrollIndicator={false}
      >
        {/* Join Our Community Section */}
        <Text
          style={{
            fontSize: 20,
            fontWeight: "bold",
            color: "#1F2937",
            marginBottom: 20,
          }}
        >
          🤝 Join Our Community
        </Text>

        {communityLinks.map((link) => {
          const IconComponent = link.icon;
          return (
            <TouchableOpacity
              key={link.id}
              style={{
                backgroundColor: "white",
                padding: 20,
                borderRadius: 16,
                marginBottom: 16,
                shadowColor: "#000",
                shadowOffset: { width: 0, height: 2 },
                shadowOpacity: 0.08,
                shadowRadius: 12,
                elevation: 3,
              }}
              onPress={() => openLink(link.url)}
              activeOpacity={0.7}
            >
              <View
                style={{
                  flexDirection: "row",
                  alignItems: "center",
                }}
              >
                <View
                  style={{
                    width: 50,
                    height: 50,
                    backgroundColor: `${link.color}15`,
                    borderRadius: 12,
                    justifyContent: "center",
                    alignItems: "center",
                    marginRight: 15,
                  }}
                >
                  <IconComponent size={24} color={link.color} />
                </View>

                <View style={{ flex: 1 }}>
                  <View
                    style={{
                      flexDirection: "row",
                      alignItems: "center",
                      marginBottom: 4,
                    }}
                  >
                    <Text
                      style={{
                        fontSize: 18,
                        fontWeight: "600",
                        color: "#1F2937",
                        flex: 1,
                      }}
                    >
                      {link.title}
                    </Text>
                    <ExternalLink size={16} color="#9CA3AF" />
                  </View>

                  <Text
                    style={{
                      fontSize: 14,
                      color: "#6B7280",
                      marginBottom: 6,
                      lineHeight: 20,
                    }}
                  >
                    {link.description}
                  </Text>

                  <View
                    style={{
                      backgroundColor: "#F3F4F6",
                      paddingHorizontal: 8,
                      paddingVertical: 4,
                      borderRadius: 8,
                      alignSelf: "flex-start",
                    }}
                  >
                    <Text
                      style={{
                        fontSize: 12,
                        color: "#6B7280",
                        fontWeight: "500",
                      }}
                    >
                      {link.members}
                    </Text>
                  </View>
                </View>
              </View>
            </TouchableOpacity>
          );
        })}

        {/* Local Events Section */}
        <Text
          style={{
            fontSize: 20,
            fontWeight: "bold",
            color: "#1F2937",
            marginTop: 30,
            marginBottom: 20,
          }}
        >
          📍 Local Events
        </Text>

        {/* Filter Buttons */}
        <View style={{ marginBottom: 20 }}>
          <Text
            style={{
              fontSize: 16,
              fontWeight: "600",
              color: "#374151",
              marginBottom: 12,
            }}
          >
            Filter Events
          </Text>

          <ScrollView
            horizontal
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={{ paddingRight: 20 }}
          >
            {eventTypes.map((type) => (
              <TouchableOpacity
                key={type.key}
                style={{
                  backgroundColor:
                    selectedFilter === type.key ? "#4ADE80" : "white",
                  paddingHorizontal: 16,
                  paddingVertical: 10,
                  borderRadius: 20,
                  marginRight: 10,
                  flexDirection: "row",
                  alignItems: "center",
                  shadowColor: "#000",
                  shadowOffset: { width: 0, height: 1 },
                  shadowOpacity: 0.05,
                  shadowRadius: 4,
                  elevation: 2,
                }}
                onPress={() => setSelectedFilter(type.key)}
                activeOpacity={0.7}
              >
                <Text style={{ fontSize: 16, marginRight: 6 }}>
                  {type.icon}
                </Text>
                <Text
                  style={{
                    fontSize: 14,
                    fontWeight: "600",
                    color: selectedFilter === type.key ? "white" : "#374151",
                  }}
                >
                  {type.label}
                </Text>
              </TouchableOpacity>
            ))}
          </ScrollView>
        </View>

        {/* Events List */}
        {filteredEvents.map((event) => {
          const IconComponent = event.icon;
          const participationPercentage =
            (event.participants / event.maxParticipants) * 100;

          return (
            <TouchableOpacity
              key={event.id}
              style={{
                backgroundColor: "white",
                borderRadius: 16,
                marginBottom: 16,
                shadowColor: "#000",
                shadowOffset: { width: 0, height: 2 },
                shadowOpacity: 0.08,
                shadowRadius: 12,
                elevation: 3,
                overflow: "hidden",
              }}
              onPress={() => openLink(event.url)}
              activeOpacity={0.7}
            >
              {/* Event Header */}
              <View
                style={{
                  backgroundColor: `${event.color}15`,
                  padding: 20,
                  borderBottomWidth: 1,
                  borderBottomColor: "#F3F4F6",
                }}
              >
                <View
                  style={{
                    flexDirection: "row",
                    alignItems: "flex-start",
                    justifyContent: "space-between",
                    marginBottom: 10,
                  }}
                >
                  <View style={{ flex: 1 }}>
                    <Text
                      style={{
                        fontSize: 18,
                        fontWeight: "600",
                        color: "#1F2937",
                        marginBottom: 4,
                      }}
                    >
                      {event.title}
                    </Text>
                    <Text
                      style={{
                        fontSize: 14,
                        color: "#6B7280",
                        fontWeight: "500",
                      }}
                    >
                      by {event.organization}
                    </Text>
                  </View>

                  <View
                    style={{
                      width: 40,
                      height: 40,
                      backgroundColor: event.color,
                      borderRadius: 20,
                      justifyContent: "center",
                      alignItems: "center",
                      marginLeft: 15,
                    }}
                  >
                    <IconComponent size={20} color="white" />
                  </View>
                </View>

                <Text
                  style={{
                    fontSize: 14,
                    color: "#374151",
                    lineHeight: 20,
                  }}
                >
                  {event.description}
                </Text>
              </View>

              {/* Event Details */}
              <View style={{ padding: 20 }}>
                <View
                  style={{
                    flexDirection: "row",
                    marginBottom: 12,
                  }}
                >
                  <View
                    style={{
                      flexDirection: "row",
                      alignItems: "center",
                      flex: 1,
                      marginRight: 10,
                    }}
                  >
                    <Calendar size={16} color="#6B7280" />
                    <Text
                      style={{
                        fontSize: 14,
                        color: "#374151",
                        marginLeft: 6,
                        fontWeight: "500",
                      }}
                    >
                      {formatDate(event.date)}
                    </Text>
                  </View>

                  <View
                    style={{
                      flexDirection: "row",
                      alignItems: "center",
                      flex: 1,
                    }}
                  >
                    <Clock size={16} color="#6B7280" />
                    <Text
                      style={{
                        fontSize: 14,
                        color: "#374151",
                        marginLeft: 6,
                        fontWeight: "500",
                      }}
                    >
                      {event.time}
                    </Text>
                  </View>
                </View>

                <View
                  style={{
                    flexDirection: "row",
                    alignItems: "center",
                    marginBottom: 15,
                  }}
                >
                  <MapPin size={16} color="#6B7280" />
                  <Text
                    style={{
                      fontSize: 14,
                      color: "#374151",
                      marginLeft: 6,
                      flex: 1,
                    }}
                  >
                    {event.location}
                  </Text>
                  <Text
                    style={{
                      fontSize: 12,
                      color: "#059669",
                      fontWeight: "600",
                    }}
                  >
                    {event.distance}
                  </Text>
                </View>

                {/* Participation Info */}
                <View
                  style={{
                    flexDirection: "row",
                    alignItems: "center",
                    justifyContent: "space-between",
                    marginBottom: 12,
                  }}
                >
                  <View
                    style={{
                      flexDirection: "row",
                      alignItems: "center",
                    }}
                  >
                    <Users size={16} color="#6B7280" />
                    <Text
                      style={{
                        fontSize: 14,
                        color: "#374151",
                        marginLeft: 6,
                      }}
                    >
                      {event.participants}/{event.maxParticipants} joined
                    </Text>
                  </View>

                  <View
                    style={{
                      flexDirection: "row",
                      alignItems: "center",
                    }}
                  >
                    <ExternalLink size={16} color="#9CA3AF" />
                    <Text
                      style={{
                        fontSize: 12,
                        color: "#9CA3AF",
                        marginLeft: 4,
                      }}
                    >
                      View Details
                    </Text>
                  </View>
                </View>

                {/* Progress Bar */}
                <View
                  style={{
                    backgroundColor: "#F3F4F6",
                    height: 6,
                    borderRadius: 3,
                    marginBottom: 10,
                  }}
                >
                  <View
                    style={{
                      backgroundColor: event.color,
                      height: 6,
                      borderRadius: 3,
                      width: `${participationPercentage}%`,
                    }}
                  />
                </View>

                <Text
                  style={{
                    fontSize: 12,
                    color: "#6B7280",
                    textAlign: "center",
                  }}
                >
                  {Math.round(participationPercentage)}% full
                </Text>
              </View>
            </TouchableOpacity>
          );
        })}

        {/* Coming Soon Section */}
        <Text
          style={{
            fontSize: 20,
            fontWeight: "bold",
            color: "#1F2937",
            marginTop: 30,
            marginBottom: 20,
          }}
        >
          🚀 Coming Soon
        </Text>

        <View
          style={{
            backgroundColor: "white",
            padding: 20,
            borderRadius: 16,
            marginBottom: 20,
            shadowColor: "#000",
            shadowOffset: { width: 0, height: 2 },
            shadowOpacity: 0.08,
            shadowRadius: 12,
            elevation: 3,
          }}
        >
          <Text
            style={{
              fontSize: 16,
              fontWeight: "600",
              color: "#1F2937",
              marginBottom: 15,
              textAlign: "center",
            }}
          >
            🎉 Phase 2: Native Community Features
          </Text>

          {upcomingFeatures.map((feature, index) => (
            <View
              key={index}
              style={{
                flexDirection: "row",
                alignItems: "center",
                paddingVertical: 12,
                borderBottomWidth: index < upcomingFeatures.length - 1 ? 1 : 0,
                borderBottomColor: "#F3F4F6",
              }}
            >
              <Text style={{ fontSize: 24, marginRight: 15 }}>
                {feature.icon}
              </Text>
              <View style={{ flex: 1 }}>
                <Text
                  style={{
                    fontSize: 16,
                    fontWeight: "600",
                    color: "#1F2937",
                    marginBottom: 2,
                  }}
                >
                  {feature.title}
                </Text>
                <Text
                  style={{
                    fontSize: 14,
                    color: "#6B7280",
                  }}
                >
                  {feature.description}
                </Text>
              </View>
            </View>
          ))}
        </View>

        {/* Community Guidelines */}
        <View
          style={{
            backgroundColor: "#ECFDF5",
            padding: 20,
            borderRadius: 16,
            borderLeftWidth: 4,
            borderLeftColor: "#4ADE80",
          }}
        >
          <Text
            style={{
              fontSize: 16,
              fontWeight: "600",
              color: "#059669",
              marginBottom: 12,
              flexDirection: "row",
              alignItems: "center",
            }}
          >
            <Heart size={16} color="#059669" /> Community Guidelines
          </Text>
          <Text
            style={{
              fontSize: 14,
              color: "#374151",
              lineHeight: 20,
              marginBottom: 8,
            }}
          >
            • Be kind and respectful to all members
          </Text>
          <Text
            style={{
              fontSize: 14,
              color: "#374151",
              lineHeight: 20,
              marginBottom: 8,
            }}
          >
            • Share eco-friendly tips and experiences
          </Text>
          <Text
            style={{
              fontSize: 14,
              color: "#374151",
              lineHeight: 20,
              marginBottom: 8,
            }}
          >
            • Support each other's sustainability journey
          </Text>
          <Text
            style={{
              fontSize: 14,
              color: "#374151",
              lineHeight: 20,
            }}
          >
            • Keep discussions focused on environmental topics
          </Text>
        </View>
      </ScrollView>
    </View>
  );
}
